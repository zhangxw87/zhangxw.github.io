function lambda = CrossValidation(X,u1,k,Lambda,options)

N = length(Lambda);
Accuracy = zeros(N,1);

% Generate index of 5-fold cross-validation
Index = crossvalind('Kfold', u1(end));
for i=1:5
    % Identify training data and testing data
    class1 = zeros(1,k);
    label = (Index==i);
    for j=1:k
        class1(j) = sum( label(1:u1(j)) );
    end
    class2 = u1 - class1;
    CX = X(:,Index==i);
    CX_test = X(:,Index~=i);
    
    for s=1:N
        options.lambda_x = Lambda(s);
        options.lambda_y = Lambda(s);
        
        CCAOutput = CCA_Classification(CX,class1,CX_test,class2,k,options);
        Accuracy(s) = Accuracy(s) + CCAOutput.accuracy_SparseCCA;
    end
    
end

[temp,ind] = max(Accuracy);
lambda = Lambda(ind);