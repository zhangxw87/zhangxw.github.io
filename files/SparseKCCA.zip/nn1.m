function accuracy=nn1(training,u,test,v)
%this algorithm gives us the nn1 accuracy
%training: training data 
%test: test data.
%u is an index labeling the training  dataset, for example u=[5, 10, 20]
%means the first 5 training data is from class 1.
%6th to 10 is from class 2.
%11 to 20 is from class 3.
 
%similarly for v, it is meant to label test data. 

[m, n]=size(training);
q=size(test,2);
k=length(u);

% k=length(v)
% u(k)=n,   v(k)=q


uu=zeros(1,n);
vv=zeros(1,q);

ll=0;
lll=0;
for i=1:k
   for j=ll+1:u(i)
       uu(j)=i;
   end
   ll=u(i);
   
   for j=lll+1:v(i)
        vv(j)=i;
   end
   lll=v(i);
end


index=zeros(1,q);
for i=1:q
    t=zeros(1,n);
    
    for j=1:n
        t(j)=norm(test(:,i)-training(:,j),'fro');
    end
    [a, I]=sort(t);
    index(i)=vv(i)-uu(I(1));
end
        
accuracy=(length(find(index==0))/q)*100;
