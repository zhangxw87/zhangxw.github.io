clear all;
load Srbct_split_1.mat;

Lambda = [1E-4, 1E-3, 1E-2, 1E-1];

options.xtol = 1E-8;
options.ytol = 1E-8;
options.mxitr = 1E+5;

disp('=============================Cross-Validation=========================');
lambda = CrossValidation(A,u1,k,Lambda,options);
fprintf('\n The regularizer obtained by Cross-validation is: %e. \n',lambda);
disp('=============================End of Cross-Validation=========================');

options.lambda_x = lambda;
options.lambda_y = lambda;

CCAOutput = CCA_Classification(A,u1,test,u2,k,options);