function CCAOutput = CCA_Classification(A,u1,test,u2,k,options)

% Construct train data matrices X and Y
[m,n] = size(A);
X = A - mean(A,2) * ones(1,n);

Y = zeros(k,n);
Y(1,:) = - sqrt(u1(1))/u1(k) * ones(1,n);
Y(1,1:u1(1)) = Y(1,1:u1(1)) + ones(1,u1(1))/sqrt(u1(1));
for i = 2:k
    Y(i,:) = - sqrt(u1(i)-u1(i-1))/u1(k) * ones(1,n);
    Y(i,u1(i-1)+1:u1(i)) = Y(i,u1(i-1)+1:u1(i)) + ones(1,u1(i)-u1(i-1))/ sqrt(u1(i)-u1(i-1));
end

% Construct test data X_test and Y_test
[Num_row,Num_col] = size(test);
X_test = test - mean(test,2) * ones(1,Num_col);

Y_test = zeros(k,Num_col);
Y_test(1,:) = - sqrt(u2(1))/u2(k) * ones(1,Num_col);
Y_test(1,1:u2(1)) = Y_test(1,1:u2(1)) + ones(1,u2(1))/sqrt(u2(1));
for i = 2:k
    Y_test(i,:) = - sqrt(u2(i)-u2(i-1))/u2(k) * ones(1,Num_col);
    Y_test(i,u2(i-1)+1:u2(i)) = Y_test(i,u2(i-1)+1:u2(i)) + ones(1,u2(i)-u2(i-1))/ sqrt(u2(i)-u2(i-1));
end

[Wx, Wy, SparWx, SparWy, corr_list,CCAOutput.time] = LS_CCA(X, Y, options);

% Accuracy of CCA
CCAOutput.accuracy_CCA = nn1(Wx'*A,u1,Wx'*test,u2);
CCAOutput.accuracy_SparseCCA = nn1(SparWx'*A,u1,SparWx'*test,u2);

% Sparsity of SparWx and SparWy
l = size(SparWx,2);                        % number of columns in Wx and Wy;
CCAOutput.Number_of_zeros_Wx = length( find( SparWx==0 ) );
CCAOutput.Sparsity_of_Wx = CCAOutput.Number_of_zeros_Wx / (m * l);

CCAOutput.Number_of_zeros_Wy = length( find( SparWy==0 ) );
CCAOutput.Sparsity_of_Wy = CCAOutput.Number_of_zeros_Wy / (k * l);

% Violation of equality constraints
CCAOutput.error_SparWx = norm( SparWx'*X*X'*SparWx - eye(l), 'fro' ) / sqrt(l);
CCAOutput.error_SparWy = norm( SparWy'*Y*Y'*SparWy - eye(l), 'fro' ) / sqrt(l);

% Applying (Wx, Wy) and (SparWx, SparWy) to training data
CCAOutput.nonsparse_train_corr_list =  diag ( Wx'*X*Y'*Wy ) ./ ...
    sqrt( diag( Wx'*X*X'*Wx ) .* diag(Wy'*Y*Y'*Wy) );
CCAOutput.nonsparse_train_corr_sum = sum(CCAOutput.nonsparse_train_corr_list);

CCAOutput.sparse_train_corr_list =  diag ( SparWx'*X*Y'*SparWy ) ./ ...
    sqrt( diag( SparWx'*X*X'*SparWx ) .* diag(SparWy'*Y*Y'*SparWy) );
CCAOutput.sparse_train_corr_sum = sum(CCAOutput.sparse_train_corr_list);

% Applying (Wx, Wy) and (SparWx, SparWy) to test data
CCAOutput.nonsparse_test_corr_list =  diag ( Wx'*X_test*Y_test'*Wy ) ./ ...
    sqrt( diag( Wx'*X_test*X_test'*Wx ) .* diag(Wy'*Y_test*Y_test'*Wy) );
CCAOutput.nonsparse_test_corr_sum = sum(CCAOutput.nonsparse_test_corr_list);

CCAOutput.sparse_test_corr_list =  diag ( SparWx'*X_test*Y_test'*SparWy ) ./ ...
    sqrt( diag( SparWx'*X_test*X_test'*SparWx ) .* diag(SparWy'*Y_test*Y_test'*SparWy) );
CCAOutput.sparse_test_corr_sum = sum(CCAOutput.sparse_test_corr_list);
