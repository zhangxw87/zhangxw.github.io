function [Wx,Wy,SparWx,SparWy,corr_list,Time] = LS_CCA(X,Y,options)

% CCA_ALBI: Sparse Kernel Canonical Correlation Analysis Based on 
% Regularized Least Squares Problems
% 
% Usage:
%     [Wx,Wy,SparWx,SparWy,corr_list,Time] = LS_CCA(X,Y,options)
%     A package implementing Fixed-Point Continuation Method for 
%     regularized least squares problems is required. The package can be found in
%     http://www.caam.rice.edu/~optimization/L1/fpc/
% 
% Input:
%   X       - Data matrix X. Each column of X is a data point. Centerized
%   Y       - Data matrix Y. Each column of Y is a data point. Centerized
%       
%   options.lambda_x    -- A positive scale denoting the regularization parameter of
%                          the regularized least squares problem for Wx. 
%   options.lambda_x    -- A positive scale denoting the regularization parameter of
%                          the regularized least squares problem for Wy. 
%   options.L           -- The number of columns in Wx and Wy.
%
% Output:
%   W_x        -- Nonsparse dual projection vectors for X. 
%   W_y        -- Nonsparse dual Projection vectors for Y. 
%   SW_x       -- Sparse dual projection vectors for X.
%   SW_y       -- Sparse dual projection vectors for X. 
%   corr_list  -- the list of correlation coefficients between training data in the projected spaces of X and Y. 
%   Time  -- a 2x1 vector storing CPU time with the first componet storing the cpu time of computing (Wx,Wy) 
%            the second storing the cpu time of computing (SWx,SWy)
%
%
% Reference:
%
%   1. Delin Chu, Li-Zhi Liao, Michael K. Ng, Xiaowei Zhang,
%   Sparse Kernel Canonical Correlation Analysis, 
%   Proceedings of IMECS, 13-15 March, 2013.
%
%   2. Xiaowei Zhang,
%   Sparse Dimensionality Reduction Methods: Algorithms and Applications,
%   PhD Thesis, National University of Singapore, July 2013.
%   http://scholarbank.nus.edu.sg/bitstream/handle/10635/48696/ZhangXW.pdf?sequence=1
%
%   Written by Xiaowei Zhang (zxwtroy87 AT gmail.com)
%
%============================================================================================================
t = cputime;
lambda_x = options.lambda_x;
lambda_y = options.lambda_y;

opts_x.xtol = options.xtol;
% opts_x.gtol = options.gtol;
opts_x.mxitr = options.mxitr;

opts_y.xtol = options.ytol;
% opts_y.gtol = options.gtol;
opts_y.mxitr = options.mxitr;

% Preprocess the input 
if size(X, 2) ~= size(Y, 2)
    error('The numbers of samples in X and Y are not equal!');
end
if size(X,1)<2 || size(Y,1)<2
    error('Need at least two features in datasets X and Y!')
end

% Compute economic QR of X with column pivoting
[U, R, E1] = qr(X,0);
X_rank = rank(R);
U1 = U(:,1:X_rank);
[Sort_R index_R] = sort(E1);
R1 = R(1:X_rank,index_R);

% Compute economic SVD of R1
[P1, Sigma1, Q1] = svd(R1,'econ');

% Compute economic QR of Y with column pivoting
[V, RR, E2] = qr(Y,0);
Y_rank = rank(RR);
V1 = V(:,1:Y_rank);
[Sort_RR index_RR] = sort(E2);
R2 = RR(1:Y_rank,index_RR);

% Compute economic SVD of R1
[P2, Sigma2, Q2] = svd(R2,'econ');

% Compute SVD of Q1'*Q2
[Pro_P1,Sigma,Pro_P2] = svd(Q1'*Q2);
m = rank(Sigma);  % m is the rank of Q1'*Q2;

% The number of columns in Wx and Wy
if isfield(options,'L')
    L = options.L;
else
    L = m;
end

% Compute Wx,Wy and the canonical correlations
Wx = []; Wy = [];
if L <=m
    corr_list = diag( Sigma(1:L,1:L) );
    
    % Compute Wx
    d1 = diag(Sigma1);
    d1 = 1./d1;
    Sigma1_inv = diag(d1);
    Wx = U1 * P1 * Sigma1_inv * Pro_P1(:,1:L);
    
    % Compute Wy
    d2 = diag(Sigma2);
    d2 = 1./d2;
    Sigma2_inv = diag(d2);
    Wy = V1 * P2 * Sigma2_inv * Pro_P2(:,1:L);
else
    error('Your l has exceeded the number of nonzero correlations!');
end

% Initial data
d1 = size(X,1); SparWx = zeros(d1,L);
d2 = size(Y,1); SparWy = zeros(d2,L);

% Compute inverse of Sigma(1:L,1:L)
dg = diag( Sigma(1:L,1:L) );
dg = 1./dg;
InvSigma = diag(dg);

% Generate Tx and Ty
Tx = Q2 * Pro_P2(:,1:L) * InvSigma;

Ty = Q1 * Pro_P1(:,1:L) * InvSigma;

% Use FPC to get SparWx and SparWy
M = [];

for i = 1:L
    fprintf('Computing the %ith (over %i)column of SparWx and SparWy! \n',i,L);
    % SparWx
    Out = fpc_bb(d1,X',Tx(:,i),1/lambda_x,M,opts_x);
    SparWx(:,i) = Out.x;
    
    % SparWy
    Out = fpc_bb(d2,Y',Ty(:,i),1/lambda_y,M,opts_y);
    SparWy(:,i) = Out.x;
end

Time = cputime - t;
