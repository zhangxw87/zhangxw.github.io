function [Wx,Wy,INITER,iter,Time,opt] = SCCAAL2(X,Y,opts)
% Sparse canonical correlation analysis by applying the augment  
% Largrangian methods of multipliers to the following problem 
%
% min - tr(Wx'XY'Wy)+ \lambda||Wx||_1 + \nv||Wy||_1
%     s.t Wx'XX'Wx = I,
%         Wy'YY'Wy = I,


if nargin < 2
    error('There must be at least two inputs: X, Y.');
end
if size(X,2) ~= size(Y,2)
    error('The number of samples in X and Y are not equal!');
end
if size(X,1)<2 || size(Y,1)<2
    error('Need at least two features in datasets X and Y!');
end

tol  = 1e-3;
tol2 = tol;
tol3 = 1e-5;      %1e-7 for tr41 tr45   1e-8 for other
maxiter  = 3e+3;
maxlam = 1e+10;          % can be change
minlam = -1e+10;        % can be change
tau = 0.99;            % update rho or not
mu = 1.02;       % % large mu, short time but low sparsity,   lower mu, long time, high sparsity;
eps = 0.999;
lam = 0.05;  % 5  
nv = 0.05;  % 100   

if isfield(opts,'epsilon')            eps = opts.eps;              end
if isfield(opts,'tol3');              tol3    = opts.tol3;         end
if isfield(opts,'maxiter')            maxiter  = opts.maxiter;     end
if isfield(opts,'maxlam');            maxlam = opts.maxlam;        end
if isfield(opts,'minlam');            minlam  = opts.minlam;       end
if isfield(opts,'tau');               tau = opts.tau;              end
if isfield(opts,'mu');                mu  = opts.mu;               end
if isfield(opts,'l');                 l = opts.l;                  end
if isfield(opts,'lam');               lam  = opts.lam;             end
if isfield(opts,'nv');                nv = opts.nv;                end

tol4 = tol3;
%% generate data
%% SVDs of data matrices
[FU,S1,useless]=svd(X,0);
r = rank(S1);
d = diag(S1);
d = d(1:r);
U = FU(:,1:r);
rho1 = d(1)^2;
minx = d(r)^2;
SX = diag(d);
clear S1 FU d;

[FV,S2,useless]=svd(Y,0);
s = rank(S2);
dy = diag(S2);
dy = dy(1:s);
V=FV(:,1:s);
rho2=dy(1)^2;
miny=dy(s)^2;
SY=diag(dy);
clear FV S2 dy;


tic;
UIX = U/SX;
VIY = V/SY;

% Initialization

rho = 1.01*max(rho1,rho2);
d1 = size(X,1);
d2 = size(Y,1);
TG0 = randn(r,l);
[UTG,useless,VTG]=svd(TG0,0);
TG = UTG*VTG';
% TG = eye(r,l);
G = UIX*TG;
Wx = G;
TQ0 = randn(s,l);
[UTQ,useless,VTQ]=svd(TQ0,0);
TQ = UTQ*VTQ';
%TQ = eye(s,l);
Q = VIY*TQ;
Wy = Q;
TLambda1 = zeros(d1,l);
TLambda2 = zeros(d2,l);
INITER = zeros(1,maxiter);
R1 = Wx - G;
R2 = Wy - Q;
mr1 = max(abs(R1(:)));
mr2 = max(abs(R2(:)));

opt = [];
opt.inmaxiter = 100;
opt.a = 0.55;   % Substantially no effec
opt.b = opt.a;
%MAIN ITERATION

for iter = 1:maxiter
    % update (G,Z,P)
    opt.rho = rho;
    opt.epsilon = eps^iter;
 
    opt.alpha = 1.01*max(1, rho/minx);
    opt.beta = 1.01*max(1, rho/miny);
    
    Wx_old = Wx; 
    Wy_old = Wy;
    tY = Y/rho;
    [Wx,Wy,G,Q,initer] = PALPM(X,tY,Wx,Wy,G,Q,lam,nv,TLambda1,TLambda2,UIX,SX,U,VIY,SY,V,opt);
    INITER(iter) = initer;
    
    %% update TLambda
    R1 = Wx - G;
    R2 = Wy - Q;
    TLambda1 = TLambda1 + R1;
    TLambda1 = min(max(TLambda1,minlam/rho),maxlam/rho);
    TLambda2 = TLambda2 + R2;
    TLambda2 = min(max(TLambda2,minlam/rho),maxlam/rho);
    
    % update rho
    mr1_old = mr1;
    mr2_old = mr2;
    mr1 = max(abs(R1(:)));
    mr2 = max(abs(R2(:)));
    if mr1>tau*mr1_old || mr2>tau*mr2_old
       % rho = min(rhomax,mu*rho);
       rho = mu*rho;
    end
    
    % stop rule
    if l == 1
       RelChg1 = norm(Wx-Wx_old, 'fro') / max(1,norm(Wx_old, 'fro'));
       RelChg2 = norm(Wy-Wy_old, 'fro') / max(1,norm(Wy_old, 'fro'));
       RelChg3 = norm(R1, 'fro');
       RelChg4 = norm(R2, 'fro');
    else
       DWx = Wx - Wx_old;
       RelChg1 = sqrt(sum(dot(DWx,DWx))/max(1,sum(dot(Wx_old,Wx_old))));
       DWy = Wy - Wy_old;
       RelChg2 = sqrt(sum(dot(DWy,DWy))/max(1,sum(dot(Wy_old,Wy_old))));
       RelChg3 = sqrt(sum(dot(R1,R1)));
       RelChg4 = sqrt(sum(dot(R2,R2)));
    end
    if RelChg1 < tol && RelChg2 < tol2 && RelChg3< tol3 && RelChg4< tol4
        break;
    end
    
end
INITER = INITER(1:iter);
Time = toc;
end

%% subfunction IRGS
function [Wx,Wy,G,Q,initer] = PALPM(X,tY,Wx,Wy,G,Q,lam,nv,TLambda1,TLambda2,UIX,SX,U,VIY,SY,V,opt)

% initialization
rho = opt.rho;
ta = opt.a;
tb = opt.b;
tlam = lam/rho;
tnv = nv/rho;
alpha = opt.alpha;
beta = opt.beta;
epsilon = opt.epsilon;
inmaxiter = opt.inmaxiter;
XtYWy = X*(Wy'*tY)';
for initer = 1:inmaxiter
    % update Wx
    temp1 = Wx - (1/ta)*(TLambda1 + Wx - G - XtYWy);
    Wx_old = Wx;
    Wx = sign(temp1).*max(abs(temp1) - tlam/ta,0);
    
    % update Wy
    temp2 = Wy - (1/tb)*(TLambda2 + Wy - Q - tY*(Wx'*X)');    % X*tY'*Wx
    Wy_old = Wy;
    Wy = sign(temp2).*max(abs(temp2) - tnv/tb,0);
    XtYWy_old = XtYWy;
    XtYWy = X*(Wy'*tY)';
    
    % update G
    LWX = Wx + TLambda1;
    temp3 = (rho/alpha)*(UIX'*(LWX-G)) + SX*(U'*G);
    [YU,USELESS,YV] = svd(temp3,0);
    TY = YU*YV';
    G_old = G;
    G = UIX*TY + LWX - U*(U'*LWX);
   
    % update Q
    LWY = Wy + TLambda2;
    temp4 = (rho/beta)*(VIY'*(LWY-Q)) + SY*(V'*Q);
    [TP,USELESS,TR] = svd(temp4,0);
    T = TP*TR';
    Q_old = Q;
    Q = VIY*T + LWY - V*(V'*LWY);
    
    DG = G_old - G;
    DWx = Wx_old - Wx;
    DWy = Wy_old - Wy;
    DQ = Q_old - Q;
    
    theta1 = DG + (ta-1)*DWx + (XtYWy_old-XtYWy);
    theta2 = DQ + (tb-1)*DWy;
  %  theta3 = (alpha/rho)*X*(X'*DG) - DG + alpha*UP*(UP'*DG);
  %  theta4 = (beta/rho)*Y*(Y'*DQ) - DQ + beta*VP*(VP'*DQ);
    
    if max(abs(theta1(:))) < (epsilon/rho) && max(abs(theta2(:)))<(epsilon/rho) %&& max(abs(theta3(:))) < (epsilon/rho) && max(abs(theta4(:))) < (epsilon/rho)
        break;
    end
end
end