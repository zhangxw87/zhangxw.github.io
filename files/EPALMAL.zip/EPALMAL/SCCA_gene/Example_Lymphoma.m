clc;clear;

load('./Lymphoma.mat');
NumClass = 3;
Ind = [42, 51, 62];
nRepeat = 10;

rate = 0.5;
l = NumClass - 1;

opts.l = l;

opts3.l = l;
opts3.lam = 0.5;
opts3.nv = 0.5;

ANS1=[]; ANS2 = []; ANS3 = [];
for outiter = 1:nRepeat
    fprintf('We are processing %i-th repeat... \n', outiter);
    RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
    
    % generate training data and test data
    [ntraining, u1, ntest, u2] = spliting(A, Ind, rate);
        
    % generate X, centered-----by training data
    NumSample = size(ntraining,2);
    c = mean(ntraining, 2);
    X1 = ntraining - c * ones(1,NumSample);
    
    % generate Y, centered----by training data
    NumClass = length(u1);
    D = zeros(NumClass,NumSample);
    n1 = u1(1);
    D(1,1:n1)=ones(1,n1)/sqrt(n1);
    for r=2:NumClass
        ni = u1(r)-u1(r-1);
        D(r,u1(r-1)+1:u1(r))=ones(1,ni)/sqrt(ni);
    end
    v = [u1(1),u1(2:end)- u1(1:end-1)];
    Y1 = D - sqrt(v') / NumSample * ones(1,NumSample);
    
    % generate X & Y centered-----by test data
    NumTest = size(ntest,2);
    c = mean(ntest, 2);
    X2 = ntest - c * ones(1,NumTest);
    
    D = zeros(NumClass,NumTest);
    n1 = u2(1);
    D(1,1:n1) = ones(1,n1) / sqrt(n1);
    for r = 2:NumClass
        ni = u2(r)-u2(r-1);
        D(r,u2(r-1)+1:u2(r)) = ones(1,ni)/sqrt(ni);
    end
    v = [u2(1),u2(2:end)- u2(1:end-1)];
    Y2 = D - sqrt(v') / NumTest * ones(1,NumTest);
    
    % construct class labels
    Group = ones(NumSample,1);
    for nit = 2:NumClass
        Group(u1(nit-1)+1:u1(nit),1) = nit;
    end
    Tlabel=ones(NumTest,1);
    for nit = 2:length(u2)
        Tlabel(u2(nit-1)+1:u2(nit),1) = nit;
    end
    
    % Augmented Lagrangian for exact solution model 
    fprintf('-------- PALMAL for Exact Model-------- \n')
    [SparWx,SparWy,W,INITER,iter,time,opt] = SCCAAL_NEW(X1,Y1,opts);
    PALMAL1.time = time;
    PALMAL1.trtraining = trace( abs( SparWx'*(X1*(Y1'*SparWy)) ) );
    PALMAL1.trtest = trace( abs( SparWx'*(X2*(Y2'*SparWy)) ) );
    PALMAL1.sparsityx = 1 - nnz(SparWx)/numel(SparWx);
    PALMAL1.sparsityy = 1 - nnz(SparWy)/numel(SparWy);
    PALMAL1.orthx = norm((SparWx'*X1)*(X1'*SparWx) - eye(l),'fro') / sqrt(l);
    PALMAL1.orthy = norm((SparWy'*Y1)*(Y1'*SparWy) - eye(l),'fro') / sqrt(l);
    PALMAL1.NumVarx = sum(sum(SparWx~=0,2)~=0);
    PALMAL1.NumVary = sum(sum(SparWy~=0,2)~=0);
    ta = SparWx'*ntraining;
    te = SparWx'*ntest;
    PALMAL1.accarcy1 = nn1(ta,u1,te,u2);
    
    ANSPALMAL1 = [PALMAL1.time,PALMAL1.accarcy1,PALMAL1.trtraining,PALMAL1.trtest,PALMAL1.orthx,PALMAL1.orthy,PALMAL1.sparsityx,PALMAL1.NumVarx];
    ANS1 = [ANS1;ANSPALMAL1];
    
    % Linearized Bregman for exact solution model 
    fprintf('-------- Linearized Bregman for Exact Model-------- \n')
    [Wx, Wy, SparWx2, SparWy2, corr, time] = CCA_ALBI(X1,Y1);
    SCCA.time = time(2);
    SCCA.trtraining = trace( abs( SparWx2'*(X1*(Y1'*SparWy2)) ) );
    SCCA.trtest = trace( abs( SparWx2'*(X2*(Y2'*SparWy2)) ) );
    SCCA.sparsityx = 1 - nnz(SparWx2)/numel(SparWx2);
    SCCA.sparsityy = 1 - nnz(SparWy2)/numel(SparWy2);
    SCCA.orthx = norm((SparWx2'*X1)*(X1'*SparWx2) - eye(l),'fro') / sqrt(l);
    SCCA.orthy = norm((SparWy2'*Y1)*(Y1'*SparWy2) - eye(l),'fro') / sqrt(l);
    SCCA.NumVarx = sum(sum(SparWx2~=0,2)~=0);
    SCCA.NumVary = sum(sum(SparWy2~=0,2)~=0);
    ta = SparWx2'*ntraining;
    te = SparWx2'*ntest;
    SCCA.accarcy1 = nn1(ta,u1,te,u2);
    
    ANSSCCA = [SCCA.time,SCCA.accarcy1,SCCA.trtraining,SCCA.trtest,SCCA.orthx,SCCA.orthy,SCCA.sparsityx,SCCA.NumVarx];
    ANS2 = [ANS2;ANSSCCA];
    
    % Augmented Lagrangian for penalty model 
    fprintf('-------- PALMAL for Penalty Model-------- \n')
    [SparWx3,SparWy3,INITER,iter,time3,opt] = SCCAAL2(X1,Y1,opts3);
    PALMAL2.time = time3;
    PALMAL2.trtraining = trace( abs( SparWx3'*(X1*(Y1'*SparWy3)) ) );
    PALMAL2.trtest = trace( abs( SparWx3'*(X2*(Y2'*SparWy3)) ) );
    PALMAL2.sparsityx = 1 - nnz(SparWx3)/numel(SparWx3);
    PALMAL2.sparsityy = 1 - nnz(SparWy3)/numel(SparWy3);
    PALMAL2.orthx = norm((SparWx3'*X1)*(X1'*SparWx3) - eye(l),'fro') / sqrt(l);
    PALMAL2.orthy = norm((SparWy3'*Y1)*(Y1'*SparWy3) - eye(l),'fro') / sqrt(l);
    PALMAL2.NumVarx = sum(sum(SparWx3~=0,2)~=0);
    PALMAL2.NumVary = sum(sum(SparWy3~=0,2)~=0);
    ta = SparWx3'*ntraining;
    te = SparWx3'*ntest;
    PALMAL2.accarcy1 = nn1(ta,u1,te,u2);
    
    ANSPALMAL2 = [PALMAL2.time,PALMAL2.accarcy1,PALMAL2.trtraining,PALMAL2.trtest,PALMAL2.orthx,PALMAL2.orthy,PALMAL2.sparsityx,PALMAL2.NumVarx];
    ANS3 = [ANS3;ANSPALMAL2];
end
ANS = mean(ANS1);
ANS_SCCA = mean(ANS2);
ANSP = mean(ANS3);

save Lymphoma_Results.mat ANS1 ANS ANS2 ANS_SCCA ANS3 ANSP;
exit;