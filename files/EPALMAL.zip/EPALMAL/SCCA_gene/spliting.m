function [training, u1, test, u2] = spliting(A, u, rate)
% A is the data matrix with each column being a data point.
% u records the accumulated number of data in all classes.
% rate is the percentage of training data, in the i-th class with ni
% points, ceil(ni*rate) is randomly selected as training data.

training = [];
test = [];

K = length(u); % number of classes
u1 = zeros(1,K);
u2 = u1;

number = u(1);
number1 = ceil(rate*number);
number2 = number - number1;
u1(1) = number1;
u2(1) = number2;
temp = rand(1,number);
[temp,index] = sort(temp); % index = randperm(number);

training = [training, A(:,index(1:number1))];
test = [test, A(:, index(number1+1:end))];

for i=2:K
    number = u(i)-u(i-1);
    number1 = ceil(rate*number);
    number2 = number-number1;
    u1(i) = u1(i-1) + number1;
    u2(i) = u2(i-1) + number2;
    temp = rand(1,number);
    [temp,index] = sort(temp);
    training = [training, A(:,u(i-1)+index(1:number1))];
    test = [test, A(:,u(i-1)+index(number1+1:end))];
end