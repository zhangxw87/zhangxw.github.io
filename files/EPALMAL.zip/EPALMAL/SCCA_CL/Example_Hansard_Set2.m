clc;clear;

load('./Hansard_EnFr20.mat');
NumSample = 400;

%%% ---- Data Set I for Hansard
Etr = E(:,1:NumSample);
ctr = mean(Etr,2);
Etr = Etr - ctr * ones(1, NumSample);
Ete = E(:,(NumSample+1):end);
cte = mean(Etr,2);
Ete = Ete - cte * ones(1, size(Ete,2));

Ftr = F(:,1:NumSample);
ctr = mean(Ftr,2);
Ftr = Ftr - ctr * ones(1, NumSample);
Fte = F(:,(NumSample+1):end);
cte = mean(Fte,2);
Fte = Fte - cte * ones(1, size(Fte,2));

lambdaSet = 10 .^ (-1:0.2:1);
opts.mu = 4;
TANSPALMAL = zeros(1,10);
ROC = 0;
for i = 1:length(lambdaSet)
    fprintf('The %i-th lambda in process \n', i)
    opts.lam = lambdaSet(i);
    
    [SparWx,SparWy,W,INITER,iter,time,opt] = SCCAAL_NEW2(Etr, Ftr,opts);
    NumCol = size(SparWx,2);
    PALMAL5.time = time;
    corr = diag(SparWx'*(Etr*(Ftr'*SparWy)));
    negcorr = find(corr<0);
    SparWy(:,negcorr)=-SparWy(:,negcorr);
    SparWy(:,negcorr)=-SparWy(:,negcorr);
    PALMAL5.trcorrsum = sum( abs( diag(SparWx'*(Etr*(Ftr'*SparWy))) ) );
    PALMAL5.tecorrsum = sum( abs( diag(SparWx'*(Ete*(Fte'*SparWy))) ) );
    PALMAL5.sparsityx = 1-nnz(SparWx)/numel(SparWx);
    PALMAL5.sparsityy = 1-nnz(SparWy)/numel(SparWy);
    PALMAL5.orthx = norm((SparWx'*Etr)*(Etr'*SparWx) - eye(NumCol),'fro')/sqrt(NumCol);
    PALMAL5.orthy = norm((SparWy'*Ftr)*(Ftr'*SparWy) - eye(NumCol),'fro')/sqrt(NumCol);
    PALMAL5.NumVarx = sum(sum(SparWx~=0,2)~=0);
    PALMAL5.NumVary = sum(sum(SparWy~=0,2)~=0);
    PALMAL5.ROC = AveragePrecisionNew(Fte, SparWy, Ete, SparWx);
    if PALMAL5.ROC > ROC
        TANSPALMAL = [PALMAL5.time,PALMAL5.ROC,PALMAL5.trcorrsum,PALMAL5.tecorrsum,PALMAL5.orthx,PALMAL5.orthy,PALMAL5.sparsityx,PALMAL5.sparsityy,PALMAL5.NumVarx,PALMAL5.NumVary];
        ROC = PALMAL5.ROC;
        save Hansard_DataSet2_Results.mat TANSPALMAL SparWx SparWy Etr Ete Ftr Fte opts;
    end
end

exit