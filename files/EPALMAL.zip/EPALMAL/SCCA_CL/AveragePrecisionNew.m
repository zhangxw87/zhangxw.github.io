function Precision = AveragePrecisionNew(X, Wx, Y, Wy)

% Check input arguments
if size(X,2) ~= size(Y,2)
    error('The number of columns in X is different from that of Y!');
else
    n = size(X,2);
end

if size(Wx,2) ~= size(Wy,2)
    error('The number of cononical components are different!');
else
    l = size(Wx,2);
end

if (size(X,1) ~= size(Wx,1)) || (size(Y,1) ~= size(Wy,1))
    error('The number of terms in X (or Y) is different form row number of Wx (Wy)!');
end

% Transformed data matrices
X = Wx' * X;
Y = Wy' * Y;

% Count the number of correct retrieval
P = zeros(1,n);

for i=1:n
    dist = zeros(1,n);
    for j=1:n
        dist(j) = norm(X(:,i) - Y(:,j));
    end
    [temp,index] = sort(dist,'descend');
    
    ind = find(index==i);
    
    P(i) = ind/n;
end
Precision = mean(P);