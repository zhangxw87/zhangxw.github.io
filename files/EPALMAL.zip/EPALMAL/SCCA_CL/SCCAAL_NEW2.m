function [Wx,Wy,W,INITER,iter,Time,opt] = SCCAAL_NEW2(X,Y,opts)
% Sparse canonical correlation analysis by applying the augment  
% Largrangian methods of multipliers to the following problem 
%
% min - tr(Wx'XY'Wy)+ \lambda||Wx||_1 + \nv||Wy||_1
%     s.t Wx'XX'Wx = I,
%         Wy'YY'Wy = I,


if nargin < 2
    error('There must be at least two inputs: X, Y.');
end
if size(X,2) ~= size(Y,2)
    error('The number of samples in X and Y are not equal!');
end
if size(X,1)<2 || size(Y,1)<2
    error('Need at least two features in datasets X and Y!');
end

tol  = 1e-3;
tol2 = tol;
tol3 = 1e-5;      %1e-7 for tr41 tr45   1e-8 for other
tol4 = tol3;
maxiter  = 3e+3;
maxlam = 1e+10;          % can be change
minlam = -1e+10;         % can be change
tau = 0.99;            % can be change
mu = 1.2;       % % large mu, short time but low sparsity,   lower mu, long time, high sparsity;
eps = 0.999;
lam = 1;

if isfield(opts,'epsilon')            eps = opts.eps;              end
if isfield(opts,'tol3');               tol3    = opts.tol3;        end
if isfield(opts,'maxiter')        maxiter  = opts.maxiter;         end
if isfield(opts,'maxlam');           maxlam = opts.maxlam;         end
if isfield(opts,'minlam');          minlam  = opts.minlam;         end
if isfield(opts,'tau');                    tau = opts.tau;         end
if isfield(opts,'mu');                       mu  = opts.mu;        end
if isfield(opts,'l');                        l = opts.l;           end
if isfield(opts,'lam');                    lam  = opts.lam;        end
if isfield(opts,'nv');                     nv = opts.nv;           end


%% generate data
[U, R, E1] = qr(X,0);
X_rank = rank(R);
U1 = U(:,1:X_rank);
[SortR, indexR] = sort(E1);
R1 = R(1:X_rank,indexR);

% Compute economic QR of Y with column pivoting
[V, RR, E2] = qr(Y,0);
Y_rank = rank(RR);
V1 = V(:,1:Y_rank);
[Sort_RR, index_RR] = sort(E2);
R2 = RR(1:Y_rank,index_RR);

% Compute economic SVD of R1
[P1, Sigma1, Q1] = svd(R1,'econ');

% Compute economic SVD of R1
[P2, Sigma2, Q2] = svd(R2,'econ');

% Compute SVD of Q1'*Q2
[Pro_P1,Sigma,Pro_P2] = svd(Q1'*Q2);
% The number of columns in Wx and Wy

% l = opts.l;
% if l > min(X_rank,Y_rank)
%     error('Your l has exceeded min{rank(X), rank(Y)}!');
% else
l = rank(Sigma);

tic;
    % Initialization
    W = eye(l);
    
    d1 = diag(Sigma1);
    d1m = min(d1)^2;
    Sigma1_inv = diag(1./d1);
    A=Sigma1_inv * Pro_P1(:,1:l);
    AW = A*W;
    Wx = U1*(P1*AW);
    
    % Compute Wy
    d2 = diag(Sigma2);
    d2m = min(d2)^2;
    Sigma2_inv = diag(1./d2);
    B= Sigma2_inv * Pro_P2(:,1:l);
    BW = B*W;
    Wy = V1*(P2*BW);

rho = 1.01*max(max(d1)^2,max(d2)^2);
% Initialization

l1 = size(A,1);
l2 = size(B,1);
TLambda1 = zeros(l1,l);
TLambda2 = zeros(l2,l);
INITERX = zeros(1,maxiter);
INITERY = zeros(1,maxiter);
R1 = P1'*(U1'*Wx) - AW;
R2 = P2'*(V1'*Wy) - BW;
mr1 = max(abs(R1(:)));
mr2 = max(abs(R2(:)));

opt = [];
opt.inmaxiter = 100;
opt.a = 0.51;   % Substantially no effec
opt.b = opt.a;
opt.c = 0.5*(1/d1m + 1/d2m);
%MAIN ITERATION

for iter = 1:maxiter
    % update (G,Z,P)
    opt.rho = rho;
    opt.epsilon = eps^iter;
 
    Wx_old = Wx; 
    Wy_old = Wy;
    
    [Wx,Wy,W,AW,BW,R1,R2,initer] = PALPM(Wx,Wy,W,AW,BW,U1,P1,V1,P2,A,B,TLambda1,TLambda2,R1,R2,lam,opt);
    INITER(iter) = initer;
    
    %% update TLambda
    TLambda1 = TLambda1 + R1;
    TLambda1 = min(max(TLambda1,minlam/rho),maxlam/rho);
    TLambda2 = TLambda2 + R2;
    TLambda2 = min(max(TLambda2,minlam/rho),maxlam/rho);
    
    % update rho
    mr1_old = mr1;
    mr2_old = mr2;
    mr1 = max(abs(R1(:)));
    mr2 = max(abs(R2(:)));
    if mr1>tau*mr1_old || mr2>tau*mr2_old
       rho = mu*rho;
    end
    
    % stop rule
    if l == 1
       RelChg1 = norm(Wx-Wx_old, 'fro') / max(1,norm(Wx_old, 'fro'));
       RelChg2 = norm(Wy-Wy_old, 'fro') / max(1,norm(Wy_old, 'fro'));
       RelChg3 = norm(R1, 'fro');
       RelChg4 = norm(R2, 'fro');
    else
       DWx = Wx - Wx_old;
       RelChg1 = sqrt(sum(dot(DWx,DWx))/max(1,sum(dot(Wx_old,Wx_old))));
       DWy = Wy - Wy_old;
       RelChg2 = sqrt(sum(dot(DWy,DWy))/max(1,sum(dot(Wy_old,Wy_old))));
       RelChg3 = sqrt(sum(dot(R1,R1)));
       RelChg4 = sqrt(sum(dot(R2,R2)));
    end
    if RelChg1 < tol && RelChg2 < tol2 && RelChg3< tol3 && RelChg4< tol4
        break;
    end
    
end
INITER = INITER(1:iter);
Time = toc;
end

%% subfunction IRGS
function [Wx,Wy,W,AW,BW,R1,R2,initer] = PALPM(Wx,Wy,W,AW,BW,U1,P1,V1,P2,A,B,TLambda1,TLambda2,R1,R2,lam,opt)
  
% initialization
rho = opt.rho;
ta = opt.a;
tb = opt.b;
tc = opt.c;
tlam = lam/rho;
epsilon = opt.epsilon;
inmaxiter = opt.inmaxiter;
for initer = 1:inmaxiter
    % update Wx
    temp1 = Wx - (1/ta)*(U1*(P1*(TLambda1 + R1)));
    Wx_old = Wx;
    Wx = sign(temp1).*max(abs(temp1) - 1/(ta*rho),0);
    R1a = P1'*(U1'*Wx);
    
    % update Wy
    temp2 = Wy - (1/tb)*(V1*(P2*(TLambda2 + R2)));
    Wy_old = Wy;
    Wy = sign(temp2).*max(abs(temp2) - tlam/tb,0);
    R2a = P2'*(V1'*Wy);
    
    % update W
    temp3 = W + (1/tc)*(A'*(TLambda1+R1a) + B'*(TLambda2+R2a));
    [YU,USELESS,YV] = svd(temp3,0);
    W = YU*YV';
    AW = A*W;
    BW_old = BW;
    BW = B*W;
    R1_old = R1;
    R1 = R1a - AW;
    R2 = R2a - BW;
    
    DWx = Wx_old - Wx;
    DWy = Wy_old - Wy;
    
    theta1 = U1*(P1*(R1 - R1_old)) + ta*DWx;
    theta2 = V1*(P2*(BW_old - BW)) + tb*DWy;
  %  theta3 = (alpha/rho)*X*(X'*DG) - DG + alpha*UP*(UP'*DG);
  %  theta4 = (beta/rho)*Y*(Y'*DQ) - DQ + beta*VP*(VP'*DQ);
    
    if max(abs(theta1(:))) < (epsilon/rho) && max(abs(theta2(:)))<(epsilon/rho) %&& max(abs(theta3(:))) < (epsilon/rho) && max(abs(theta4(:))) < (epsilon/rho)
        break;
    end
end
end