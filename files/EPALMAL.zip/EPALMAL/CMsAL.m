function [X,Y,J,Error_orth,l1norm,iter,INITER,Time] = CMsAL(A,k,X,opts)
%
% This is a slover for 
%
% Compressing modes (CMs)
% Largrangian methods of multipliers to the following problem 
%
% min 1/mu ||X||_1 + Tr(X'AX)
% s.t X'X = I
% 
% subproblem solved by proximal linearized alternating minimization (PALM) method
% ----------------------------------------------------------
% input: 
%         A  - the discreted Hamiltonian in the electronic structure context
%         X  - the initinal value 
%         k  -  the number of columns in X
%         opts - parameters 
% output:
%                   X: optimal solution
%                   Y: Y should be equal to X (as the auxiliary variable)
%        Errorth_orth: feasibility 
%              l1norm: l1-norm of X
%                iter: No. of outer iterations
%              INITER: No. of inner iterations
%               Times: CPU time
% ----------------------------------------------------------
% Reference: 
% Nonconvex and Nonsmooth Optimization with Generalized Orthogonality Constraints: 
%                     An Approximate Augmented Lagrangian Method
%
% Author: 
% Hong Zhu, Xiaowei Zhang, Delin Chu, Li-Zhi Liao
%-------------------------------------------------------------------------

if nargin < 2
    error('There must be at least two inputs: A, k.');
end

maxiter  = 1e+4;
maxlam = 100;          % can be change
minlam = -100;         % can be change
tau = 0.99;            % can be change
tmu = 1.01;             % can be change
mu = 30;
mrho = 6;

if isfield(opts,'tol');                    tol = opts.tol;         end
if isfield(opts,'tol2');                 tol2 = opts.tol2;         end
if isfield(opts,'epsilon')             eps = opts.epsilon;         end
if isfield(opts,'maxiter')        maxiter  = opts.maxiter;         end
if isfield(opts,'maxlam');           maxlam = opts.maxlam;         end
if isfield(opts,'minlam');          minlam  = opts.minlam;         end
if isfield(opts,'tau');                    tau = opts.tau;         end
if isfield(opts,'tmu');                   tmu  = opts.tmu;         end
if isfield(opts,'mu');                      mu  = opts.mu;         end
if isfield(opts,'mrho');                mrho  = opts.mrho;         end                 

tic;
%% Initialization
n = size(A,1);
%lamH = eigs(A,1,'sa');
mH = norm(A,2);
lamH = eigs(A,1,'sa');
rho = 2*abs(lamH) + k/mrho;
%X = rand(n,k);
Y = X;
TLambda = zeros(n,k);
R1 = X - Y;
opt.b = 0.5;
opt.mu = mu;
opt.inmaxiter = 100;
INITER = zeros(maxiter,1);
mr1=max(abs(R1(:)));
AX =  A*X;
J = sum(abs(X(:)))/mu + sum(dot(X,AX,1));

%MAIN ITERATION
for iter = 1:maxiter
    % update (G,Z,P)
    opt.rho = rho;
    opt.epsilon = eps^iter;
    opt.a = 0.51*(2*mH/rho + 1);
    
   % X_old = X;
    [X,Y,AX,initer] = PALM(A,X,Y,AX,TLambda,opt);
    INITER(iter) = initer;
    J_old = J;
    J = sum(abs(X(:)))/mu + sum(dot(X,AX,1));
    
    % update TLambda
    R1 = X - Y;
    TLambda = TLambda - R1;
    TLambda = min(max(TLambda,minlam/rho),maxlam/rho);   
    
    % update rho
    mr1_old = mr1;
    mr1 = max(abs(R1(:)));
    if mr1>tau*mr1_old 
        rho = tmu*rho;
    end
    
    % stop rule
     RelChg2 = sqrt(sum(dot(R1,R1,1)));
     if abs(J - J_old)/max(1,abs(J_old)) < tol && RelChg2 < tol2
         break;
     end
end
Error_orth = norm(X'*X - eye(k),'fro')/sqrt(k);
l1norm = sum(abs(X(:)));
INITER = INITER(1:iter);
Time = toc;
end

%% subfunction PALM
function [X,Y,AX,initer] = PALM(A,X,Y,AX,TLambda,opt)

% initialization
rho = opt.rho;
a = opt.a;
b = opt.b;
mu = opt.mu;
tep = opt.epsilon/rho;
inmaxiter = opt.inmaxiter;

for initer = 1:inmaxiter
    % update X
    temp1 = X - (1/a)*((2/rho)*AX - TLambda + X - Y);
    X_old = X;
    X = sign(temp1).*max(abs(temp1) - 1/(a*mu*rho),0);
    AX_old = AX;
    AX = A*X;
    
    % update Y
 %   temp2 = Y - (1/b)*(TLambda + Y - X);   %L
    temp2 = X - TLambda + b*Y;
    Y_old = Y;
    [U,useless,V] = svd(temp2,0);
    Y = U*V';
    
    DY = Y - Y_old;
    theta1 = (2/rho)*(AX - AX_old) + (1-a)*(X-X_old) - DY;
    
    if max(abs(theta1(:))) < tep && max(abs(DY(:)))<(tep/abs(1-b)) 
        break;
    end
end
end