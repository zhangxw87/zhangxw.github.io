function [Accuracy, Time]  = ILDA_LSQR(training1, label_tr1, training2, label_tr2, test, label_te, epsilon)
%
% Perfrom incremental linear discriminant analysis via LSQR
%
% =========================================================================
% INPUTS:
%         training1: initial data matrix with each column being a data
%         label_tr1: a row vector with each element denoting the class label of data points in training1
%         training2: incrementally added data matrix with each column being a data
%         label_tr2: a row vector with each element denoting the class label of data points in training2
%              test: test data matrix with each column being a data
%          label_te: a row vector with each element denoting the class label of data points in test
% insert_number_set: a vector of integers consisting of the number of data points inserted in each chunk  
% 
% OUTPUTS:
%              Accuracy.batch: accuracy computed by batch algorithm when data are inserted one by one
%                  Time.batch: CPU time taken by batch algorithm  when data are inserted one by one
%      Accuracy.single_insert: accuracy by inserting the data point one by one
%          Time.single_insert: CPU time taken by inserting the data point one by one
% Accuracy.chunk_SingleInsert: accuracy by sequential algorithm when data points in a chunk are inserted sequentially (one by one)
%     Time.chunk_SingleInsert: CPU time taken by sequential algorithm when data points in a chunk are inserted sequentially (one by one)
%              Accuracy.chunk: accuracy by inserting the data point chunk by chunk
%                  Time.chunk: CPU time taken by inserting the data chunk by chunk
% =========================================================================
% Reference:
% Xiaowei Zhang, Li Cheng, Delin Chu, Li-Zhi Liao, Michael K. Ng, and Roger C. E. Tan.
% Incremental regularized least squares for dimensionality reduction of large-scale data
%
% Written by Xiaowei Zhang (zxwtroy87@gmail.com), 2015
% =========================================================================
%
insert_number_total = length(label_tr2);

Time.batch = zeros(1,insert_number_total+1);
Time.single_insert = zeros(1,insert_number_total);

n = length(label_tr1);
training = [training1 training2]; label_tr = [label_tr1 label_tr2];

% Batch learning using LDA_LSQR (initial step)
[G, E, label, Time.batch(1)] = LDA_LSQR(training1, label_tr1, epsilon);
A1 = training1; E1 = E; G1 = G; label1 = label; 

% update when one new sample is inserted
for i=1:insert_number_total
    insert_data = training2(:,i);

    label_t = label_tr2(i);

    % LDA_LSQR for single insertion
    [G, ~, ~, Time.batch(i+1)] = LDA_LSQR(training(:,1:n+i), label_tr(1:n+i), epsilon);
    
    % ILDA_LSQR(sequential) for single insertion
    [G1, A1, E1, label1, Time.single_insert(i)] = Single_Insert(G1, A1, E1, label1, insert_data, label_t, epsilon);
 
end

Accuracy.batch = nn1(G'*training, label_tr, G'*test, label_te);
Accuracy.single_insert = nn1(G1'*training, label_tr, G1'*test, label_te);

end


%% ============================================================================
%                          ILDA_LSQR single insertion   
%==============================================================================
function [G, A, E, label, ctime] = Single_Insert(G, A, E, label, insert_data, label_t, epsilon)
ctime = tic;

% update data matrix and label vector
A = [A insert_data];

r = -(G'*insert_data);

nRepeat = 20;

if ismember(label_t,label)
    % from existing class     
    e = (label == label_t);
    r(e) = r(e) + 1;
    E = [E; double(e)];
    
    [alpha, ind] = max(abs(r));    
    % solve the least squares problem
    [g, ~, ~] = lsqr2(A', E(:,ind), epsilon, nRepeat);
    if alpha > 0 
        q = (g - G(:,ind)) / r(ind);
        G = G + q*r';
    end
else
    % from a new class
    E(end+1,end+1) = 1; 
    % solve the least squares problem
    [q, ~] = lsqr2(A', E(:,end), epsilon, nRepeat);
    
    G = [G + q*r' q];
    label = [label label_t];
end

ctime = toc(ctime);

end

