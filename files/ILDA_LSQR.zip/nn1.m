function accuracy = nn1(training,label_tr,test,label_te)
% 
% This algorithm implements the Nearest Neighbor classifier. A more sophisticated implementation
% is MATLAB built-in function knnclassifier. 
%
% =========================================================================
% INPUTS:
% training: training data with each column being a data point
%     test: test data with each column being a data point
% label_tr: a row vector consisting of class labels of training
% label_te: a row vector consisting of class label of test
%
% OUTPUTS:
% accuracy: classification accuracy in percentage
% =========================================================================
%
% Written by Xiaowei Zhang (zxwtroy87@gmail.com), 2014
%
% =========================================================================

if size(training,1)~=size(test,1)
    error('Traning and test data must have the same dimension!')
end

if size(training,2)~=length(label_tr) || size(test,2)~=length(label_te)
    error('The number of data points does not match the number of labels!');
else
    n_te = length(label_te);
end

index = zeros(1,n_te);
for i=1:n_te
    temp = bsxfun(@minus,training,test(:,i));
    t = sum(temp.^2,1);    

    [~, I] = min(t);
    index(i) = (label_te(i)==label_tr(I(1)));
end

accuracy = (sum(index) / n_te) * 100;
