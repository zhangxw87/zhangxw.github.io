function [G, E, label, ctime] = LDA_LSQR(training, label_tr, lambda, options)
%
% Perfrom linear discriminant analysis based on the data-lifting trick.
% The resulting regularized least squares problem
%
% min \| A * G - E \|_F^2 + lambda^2 * \|G\|_F^2
%
% is solved by LSQR
%
% =========================================================================
% INPUTS:
% training: initial data matrix with each column being a data
% label_tr: a row vector with each element denoting the class label of data points in training
%   lambda: a positive parameter scalar (regularization parameter)
% 
% OUTPUTS:
%       G: LDA linear transformation
%   label: a row vector recording class labels appearing in training
%   ctime: CPU time
% =========================================================================
% Reference:
% Xiaowei Zhang, Li Cheng, Delin Chu, Li-Zhi Liao, Michael K. Ng, and Roger C. E. Tan.
% Incremental regularized least squares for dimensionality reduction of large-scale data
%
% Written by Xiaowei Zhang (zxwtroy87@gmail.com), 2015
% =========================================================================

if (~exist('options','var'))
   options = [];
end

nRepeat = 20;
if isfield(options,'nRepeat')
    nRepeat = options.nRepeat;
end

ctime = tic;

label = unique(label_tr); % get the class labels appeared in the data
E = bsxfun(@eq, label_tr', label); % construct label matrix 
E = double(E);

[G, ~] = lsqr2(training', E, lambda, nRepeat);

ctime = toc(ctime);

end  % End of LDA_LSQR
